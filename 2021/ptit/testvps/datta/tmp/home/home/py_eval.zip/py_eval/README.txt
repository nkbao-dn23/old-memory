docker build -t eval .
docker-compose up -d