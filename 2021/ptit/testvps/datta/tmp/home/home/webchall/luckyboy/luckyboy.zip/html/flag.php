<?php 



$flag="Q2hyaXN0Q1RGe07DtC1lbi1adWkteuG6uy1uaGUhLE3huqV5LWLhuqFuLWPDsy1n4bqldS1jaMawYS1jaOG7qS10dWktY8OzLWfhuqV1LXLhu5NpLcSRw7N9"; ?>
