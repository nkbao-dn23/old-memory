<?php
	$db=mysqli_connect("database","vietnam","asddva8439hefe4j","bank");
	mysqli_set_charset($db, 'UTF8');
?>